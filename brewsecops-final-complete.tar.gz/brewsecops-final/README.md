# ☕ BrewSecOps - Aking's Coffee

**Brew Beautifully, Deploy Securely**

Complete DevSecOps platform ready for AWS ECS deployment.

---

## 🚀 Quick Start

```powershell
# 1. Make sure Docker Desktop is running

# 2. Start everything
docker-compose up -d

# 3. Wait 30 seconds, then open:
http://localhost:5173
```

That's it!

---

## 📊 Services

| Service | URL |
|---------|-----|
| Frontend | http://localhost:5173 |
| Backend | http://localhost:3001 |
| Database | localhost:5432 |

---

## 🛠️ Commands

```powershell
docker-compose logs -f      # View logs
docker-compose ps           # Check status
docker-compose down         # Stop
docker-compose down -v      # Stop + delete data
```

---

## 👨‍💻 Author

**Aking** - DevSecOps Engineer
